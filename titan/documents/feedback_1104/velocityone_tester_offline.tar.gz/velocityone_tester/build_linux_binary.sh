#!/bin/bash
# ==============================================================================
# Build Standalone Linux Binary using PyInstaller
# ==============================================================================

set -e
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

echo "=== Building Standalone Linux Binary for VelocityOne Tester ==="

# Check PyInstaller
if ! python3 -m pip show pyinstaller > /dev/null 2>&1; then
    echo "Installing PyInstaller..."
    python3 -m pip install pyinstaller
fi

# Clean previous builds
rm -rf build dist

echo "Packaging standalone binary..."
pyinstaller \
    --name "velocityone_tester" \
    --onefile \
    --add-data "static:static" \
    --hidden-import "uvicorn" \
    --hidden-import "fastapi" \
    --hidden-import "evdev" \
    app_launcher.py

echo "=========================================================="
echo "✓ Build Complete! Binary created at: dist/velocityone_tester"
echo "You can run it directly: ./dist/velocityone_tester"
echo "=========================================================="
