#!/bin/bash
# ==============================================================================
# VelocityOne Tester - One-Click Launcher (Offline & Zero-Sudo)
# ==============================================================================

set -e
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

# 1. Ensure display environment variable is set for GUI
export DISPLAY="${DISPLAY:-:0}"
export PYTHONPATH="$SCRIPT_DIR/libs:$HOME/.local/lib/python3.12/site-packages:$HOME/.local/lib/python3.10/site-packages:$HOME/.local/lib/python3.11/site-packages:$PYTHONPATH"

# 2. Check if dependencies are ready; auto-install offline if not
if [ ! -d "$SCRIPT_DIR/libs" ] || [ ! -f "$SCRIPT_DIR/libs/fastapi/__init__.py" ]; then
    chmod +x ./install.sh
    ./install.sh
fi

# 3. Launch application
exec python3 app_launcher.py
