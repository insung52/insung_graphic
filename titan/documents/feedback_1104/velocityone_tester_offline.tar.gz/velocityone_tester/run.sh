#!/bin/bash
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

PYTHON_BIN=""
if [ -f "./venv/bin/python" ] && ./venv/bin/python -c "import fastapi" 2>/dev/null; then
    PYTHON_BIN="./venv/bin/python"
elif python3 -c "import fastapi" 2>/dev/null; then
    PYTHON_BIN="python3"
elif sudo python3 -c "import fastapi" 2>/dev/null; then
    PYTHON_BIN="sudo python3"
else
    echo "fastapi not found. Auto-running ./install.sh to fix dependencies..."
    ./install.sh
    if [ -f "./venv/bin/python" ] && ./venv/bin/python -c "import fastapi" 2>/dev/null; then
        PYTHON_BIN="./venv/bin/python"
    else
        PYTHON_BIN="python3"
    fi
fi

# Detect local IP address
LOCAL_IP=$(hostname -I 2>/dev/null | awk '{print $1}' || echo "localhost")

echo "=========================================================="
echo "✈ Turtle Beach VelocityOne Tester Server Starting..."
echo "Using Python: $PYTHON_BIN"
echo "----------------------------------------------------------"
echo "Open your web browser at:"
echo "   http://localhost:8000"
echo "   http://${LOCAL_IP}:8000"
echo "=========================================================="

exec $PYTHON_BIN main.py
