document.addEventListener('DOMContentLoaded', () => {
  const statusBadge = document.getElementById('status-badge');
  const simBadge = document.getElementById('sim-badge');
  const deviceNameEl = document.getElementById('device-name');
  
  const valX = document.getElementById('val-x');
  const valY = document.getElementById('val-y');
  const valRX = document.getElementById('val-rx');
  const valRY = document.getElementById('val-ry');
  const valRZ = document.getElementById('val-rz');
  const valThrottle = document.getElementById('val-throttle');
  const valRudder = document.getElementById('val-rudder');
  const valZ = document.getElementById('val-z');

  const barRZ = document.getElementById('bar-rz');
  const barThrottle = document.getElementById('bar-throttle');
  const barRudder = document.getElementById('bar-rudder');
  const yawIndicator = document.getElementById('yaw-indicator');

  const buttonsContainer = document.getElementById('buttons-container');
  const eventLog = document.getElementById('event-log');

  const mainCanvas = document.getElementById('main-stick-canvas');
  const mainCtx = mainCanvas.getContext('2d');

  const subCanvas = document.getElementById('sub-stick-canvas');
  const subCtx = subCanvas.getContext('2d');

  let socket = null;
  let knownButtons = new Set();
  let lastEventTime = 0;

  // Render 2D Stick Canvas
  function drawStick(ctx, width, height, xVal, yVal) {
    ctx.clearRect(0, 0, width, height);
    const cx = width / 2;
    const cy = height / 2;
    const radius = width / 2 - 15;

    // Outer Circle Ring
    ctx.beginPath();
    ctx.arc(cx, cy, radius, 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Crosshairs
    ctx.beginPath();
    ctx.moveTo(cx - radius, cy); ctx.lineTo(cx + radius, cy);
    ctx.moveTo(cx, cy - radius); ctx.lineTo(cx + radius, cy);
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
    ctx.lineWidth = 1;
    ctx.stroke();

    // Vector Line
    const dotX = cx + (xVal * radius);
    const dotY = cy + (yVal * radius);
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.lineTo(dotX, dotY);
    ctx.strokeStyle = 'rgba(0, 240, 255, 0.4)';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Dot Glow
    ctx.beginPath();
    ctx.arc(dotX, dotY, 10, 0, Math.PI * 2);
    ctx.fillStyle = '#00f0ff';
    ctx.shadowColor = '#00f0ff';
    ctx.shadowBlur = 12;
    ctx.fill();
    ctx.shadowBlur = 0;
  }

  function appendLog(msg, type = 'event') {
    const entry = document.createElement('div');
    entry.className = `log-entry ${type}`;
    const timestamp = new Date().toLocaleTimeString();
    entry.textContent = `[${timestamp}] ${msg}`;
    eventLog.appendChild(entry);
    eventLog.scrollTop = eventLog.scrollHeight;

    while (eventLog.children.length > 50) {
      eventLog.removeChild(eventLog.firstChild);
    }
  }

  function cssClean(str) {
    return 'btn_' + String(str).replace(/[^a-zA-Z0-9]/g, '_');
  }

  function naturalSort(a, b) {
    const matchA = a.match(/^B(\d+)$/);
    const matchB = b.match(/^B(\d+)$/);

    if (matchA && matchB) {
      return parseInt(matchA[1], 10) - parseInt(matchB[1], 10);
    }
    if (matchA) return -1;
    if (matchB) return 1;

    return a.localeCompare(b);
  }

  function updateButtons(buttons) {
    const sortedKeys = Object.keys(buttons).sort(naturalSort);

    sortedKeys.forEach(btnKey => {
      const cleanId = cssClean(btnKey);
      let btnEl = document.getElementById(cleanId);
      if (!btnEl) {
        btnEl = document.createElement('div');
        btnEl.id = cleanId;
        btnEl.className = 'btn-item';
        btnEl.textContent = btnKey;
        knownButtons.add(btnKey);
      }
      buttonsContainer.appendChild(btnEl);

      if (buttons[btnKey]) {
        btnEl.classList.add('active');
      } else {
        btnEl.classList.remove('active');
      }
    });
  }

  function connectWebSocket() {
    const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${location.host}/ws/joystick`;
    
    socket = new WebSocket(wsUrl);

    socket.onopen = () => {
      appendLog('Connected to VelocityOne backend service.', 'system');
    };

    socket.onmessage = (event) => {
      const data = JSON.parse(event.data);

      // Hardware Connection State & Badge Logic
      if (data.connected) {
        statusBadge.textContent = 'CONNECTED';
        statusBadge.className = 'badge connected';
        simBadge.classList.add('hidden');
      } else {
        statusBadge.textContent = 'DISCONNECTED';
        statusBadge.className = 'badge disconnected';
        if (data.simulation_mode) {
          simBadge.classList.remove('hidden');
        } else {
          simBadge.classList.add('hidden');
        }
      }

      deviceNameEl.textContent = data.device_name || (data.connected ? 'Turtle Beach VelocityOne Flightstick' : 'No Hardware');

      const axes = data.axes || {};
      
      // Primary Pitch (Y) / Roll (X)
      const x = axes.ABS_X ?? 0.0;
      const y = axes.ABS_Y ?? 0.0;

      // H2 Mini Stick RX / RY (-1.0 to 1.0)
      const rx = axes.ABS_RX ?? 0.0;
      const ry = axes.ABS_RY ?? 0.0;

      // Stick Twist Yaw Z (-1.0 to 1.0)
      const z = axes.ABS_Z ?? 0.0;

      // Throttle Levers & Trim (0.0 to 1.0 -> 0% ~ 100%)
      const rz = axes.ABS_RZ ?? 0.0;
      const throttle = axes.ABS_THROTTLE ?? 0.0;
      const rudder = axes.ABS_RUDDER ?? 0.0;

      valX.textContent = x.toFixed(2);
      valY.textContent = y.toFixed(2);
      valRX.textContent = rx.toFixed(2);
      valRY.textContent = ry.toFixed(2);
      valZ.textContent = z.toFixed(2);

      barRZ.style.height = `${(rz * 100).toFixed(1)}%`;
      valRZ.textContent = `${Math.round(rz * 100)}%`;

      barThrottle.style.height = `${(throttle * 100).toFixed(1)}%`;
      valThrottle.textContent = `${Math.round(throttle * 100)}%`;

      barRudder.style.height = `${(rudder * 100).toFixed(1)}%`;
      valRudder.textContent = `${Math.round(rudder * 100)}%`;

      // Handle Twist Yaw (-1.0 to 1.0 -> 0% to 100%)
      const yawPercent = 50 + (z * 50);
      yawIndicator.style.left = `${Math.min(100, Math.max(0, yawPercent))}%`;

      // Draw 2D Canvases
      drawStick(mainCtx, mainCanvas.width, mainCanvas.height, x, y);
      drawStick(subCtx, subCanvas.width, subCanvas.height, rx, ry);

      if (data.buttons) {
        updateButtons(data.buttons);
      }

      if (data.last_event && data.last_event.time > lastEventTime) {
        lastEventTime = data.last_event.time;
        const e = data.last_event;
        if (e.type === 'EV_KEY') {
          appendLog(`Button ${e.code} => ${e.value ? 'PRESSED' : 'RELEASED'}`, 'event');
        } else if (e.type === 'EV_ABS') {
          appendLog(`Axis ${e.code} => ${e.value}`, 'event');
        } else if (e.type === 'EV_REL') {
          appendLog(`Touchpad Swipe: ${e.code} => Delta: ${e.value}`, 'event');
        }
      }
    };

    socket.onclose = () => {
      statusBadge.textContent = 'SERVER OFFLINE';
      statusBadge.className = 'badge disconnected';
      simBadge.classList.add('hidden');
      appendLog('Backend server offline. Reconnecting in 2 seconds...', 'system');
      setTimeout(connectWebSocket, 2000);
    };

    socket.onerror = (err) => {
      console.error('WebSocket error:', err);
    };
  }

  connectWebSocket();
});
