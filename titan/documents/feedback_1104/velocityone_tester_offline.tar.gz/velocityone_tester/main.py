import os
import sys

# Ensure local libs and user site-packages are loaded first
script_dir = os.path.dirname(os.path.abspath(__file__))
libs_dir = os.path.join(script_dir, "libs")
if os.path.isdir(libs_dir) and libs_dir not in sys.path:
    sys.path.insert(0, libs_dir)

py_ver = f"{sys.version_info.major}.{sys.version_info.minor}"
user_site = os.path.expanduser(f"~/.local/lib/python{py_ver}/site-packages")
if os.path.isdir(user_site) and user_site not in sys.path:
    sys.path.insert(0, user_site)

import asyncio
import json
import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from joystick_reader import JoystickReader

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('main')

joystick = JoystickReader()

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting Joystick Reader service...")
    await joystick.start_reading()
    yield
    logger.info("Shutting down Joystick Reader service...")

app = FastAPI(title="Turtle Beach VelocityOne Tester", lifespan=lifespan)

active_connections: list[WebSocket] = []

@app.get("/api/status")
async def get_status():
    return joystick.get_state()

@app.websocket("/ws/joystick")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    active_connections.append(websocket)
    logger.info(f"WebSocket client connected. Total clients: {len(active_connections)}")
    try:
        while True:
            state = joystick.get_state()
            await websocket.send_json(state)
            await asyncio.sleep(1 / 30.0) # 30 FPS update rate
    except WebSocketDisconnect:
        if websocket in active_connections:
            active_connections.remove(websocket)
        logger.info("WebSocket client disconnected.")
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        if websocket in active_connections:
            active_connections.remove(websocket)

def get_resource_path(relative_path: str) -> str:
    """Get absolute path to resource, works for dev and for PyInstaller"""
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, relative_path)
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), relative_path)

static_dir = get_resource_path("static")
os.makedirs(static_dir, exist_ok=True)
app.mount("/static", StaticFiles(directory=static_dir), name="static")

@app.get("/")
async def read_index():
    return FileResponse(os.path.join(static_dir, "index.html"))

def run_server(host: str = "0.0.0.0", port: int = 8000):
    import uvicorn
    uvicorn.run(app, host=host, port=port, reload=False, log_level="info")

if __name__ == "__main__":
    run_server()
