#!/usr/bin/env python3
"""
Korea Copyright Commission (한국저작권위원회) Source Code Exporter
Formats and exports project source code with standard headers, line numbers,
and pagination for official software copyright registration submission.
"""

import os
import sys
import datetime

TARGET_FILES = [
    # Core Backend
    ("main.py", "FastAPI WebSocket & HTTP Server Core"),
    ("joystick_reader.py", "Linux evdev / Hardware Input & Simulation Engine"),
    ("app_launcher.py", "All-in-One Standalone Desktop Launcher"),
    
    # Frontend UI
    ("static/app.js", "Real-time WebSocket Visualizer & UI Controller"),
    ("static/index.html", "Dashboard UI Structure & Component Layout"),
    ("static/style.css", "Aviation Cockpit Styling & Responsive Theme"),
    
    # Automation & Scripts
    ("launch.sh", "Linux One-Click Execution Shell Script"),
    ("install.sh", "System udev & Permissions Installer"),
    ("build_linux_binary.sh", "PyInstaller Standalone Binary Build Script"),
    ("velocityone_tester.desktop", "Linux Desktop Shortcut Entry")
]

LINES_PER_PAGE = 50

def generate_copyright_export():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    output_path = os.path.join(script_dir, "copyright_source_submission.txt")
    
    now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    total_lines = 0
    file_contents = []

    for rel_path, desc in TARGET_FILES:
        full_path = os.path.join(script_dir, rel_path)
        if not os.path.isfile(full_path):
            continue
        
        with open(full_path, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
        
        total_lines += len(lines)
        file_contents.append((rel_path, desc, lines))

    # Build formatted document
    doc_lines = []
    
    # Title & Metadata Header
    doc_lines.append("=" * 80)
    doc_lines.append("한국저작권위원회(CROS) 컴퓨터프로그램저작물 등록 제출용 소스코드 복제물")
    doc_lines.append("=" * 80)
    doc_lines.append(f"프로그램 명칭 : Turtle Beach VelocityOne Flightstick/Yoke Hardware Tester & Monitor")
    doc_lines.append(f"버전          : v1.0.0")
    doc_lines.append(f"작성 일자     : {now_str}")
    doc_lines.append(f"개발 언어     : Python, JavaScript, HTML5, CSS3, Bash Shell")
    doc_lines.append(f"대상 운영체제 : Linux (Ubuntu, Debian, RHEL, CentOS 등)")
    doc_lines.append(f"총 파일 수    : {len(file_contents)} 개")
    doc_lines.append(f"총 소스 라인  : {total_lines} 라인")
    doc_lines.append("-" * 80)
    doc_lines.append("【 포함된 소스코드 파일 목록 】")
    for idx, (fname, fdesc, flines) in enumerate(file_contents, 1):
        doc_lines.append(f"  {idx:2d}. {fname:<30} ({len(flines):4d} lines) - {fdesc}")
    doc_lines.append("=" * 80)
    doc_lines.append("\n\n")

    current_global_line = 0
    for fname, fdesc, flines in file_contents:
        doc_lines.append("\n" + "#" * 80)
        doc_lines.append(f"### [FILE START] {fname} ({fdesc})")
        doc_lines.append("#" * 80 + "\n")
        
        for l_num, line in enumerate(flines, 1):
            current_global_line += 1
            content = line.rstrip("\r\n")
            doc_lines.append(f"{l_num:4d} | {content}")
        
        doc_lines.append("\n" + "#" * 80)
        doc_lines.append(f"### [FILE END] {fname}")
        doc_lines.append("#" * 80 + "\n\n")

    # Add Page Markers
    paginated_output = []
    page_num = 1
    line_count_in_page = 0
    
    for line in doc_lines:
        paginated_output.append(line)
        line_count_in_page += 1
        if line_count_in_page >= LINES_PER_PAGE:
            paginated_output.append(f"\n--- [ PAGE {page_num} ] --------------------------------------------------------\n")
            page_num += 1
            line_count_in_page = 0
            
    if line_count_in_page > 0:
        paginated_output.append(f"\n--- [ PAGE {page_num} (END) ] --------------------------------------------------\n")

    with open(output_path, "w", encoding="utf-8") as out:
        out.write("\n".join(paginated_output))

    print("=" * 60)
    print("✓ 저작권 등록 제출용 소스코드 문서가 성공적으로 생성되었습니다.")
    print(f"  출력 파일: {output_path}")
    print(f"  총 페이지 수: 약 {page_num} 페이지 (총 {total_lines} 라인)")
    print("=" * 60)
    return output_path

if __name__ == "__main__":
    generate_copyright_export()
