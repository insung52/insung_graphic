# 한국저작권위원회(CROS) 컴퓨터프로그램 저작권 등록 실무 가이드

본 문서는 **한국저작권위원회 저작권등록시스템 (https://www.cros.or.kr)**에 본 프로그램을 정식 등록하기 위한 단계별 가이드입니다.

---

## 1. 사전 준비물 확인

1. **신청자 정보**: 공동/개인 저작자 정보 (또는 법인 명의인 경우 사업자등록증)
2. **프로그램 설명서/개요서**: [`docs/program_description.md`](file:///Users/choihayoung/velocityone_tester/docs/program_description.md) 파일 내용을 기반으로 작성
3. **소스코드 복제물 파일**: [`copyright_source_submission.txt`](file:///Users/choihayoung/velocityone_tester/copyright_source_submission.txt) (전체 약 30페이지)
4. **수수료**: 온라인 신청 기준 약 50,000원 ~ 60,000원 내외 (개인/중소기업 감면 혜택 가능 여부 확인)

---

## 2. 저작권등록시스템(CROS) 단계별 신청 절차

### [1단계] 사이트 접속 및 로그인
1. [한국저작권위원회 CROS (https://www.cros.or.kr)](https://www.cros.or.kr) 접속
2. 공동인증서/간편인증 로그인

### [2단계] 등록 신청 메뉴 이동
- 상단 메뉴: **[등록신청]** -> **[프로그램등록]** -> **[프로그램등록 신청]** 클릭

### [3단계] 기본 정보 입력 (신청서 작성)
- **프로그램 명칭**: `Turtle Beach VelocityOne Flightstick/Yoke Hardware Tester & Monitor`
  *(한글 병기: 터틀비치 벨로시티원 플라이트스틱 하드웨어 테스터 및 모니터링 시스템)*
- **프로그램 종류**: `응용 프로그램` > `기타 시스템/유틸리티 응용소프트웨어` (또는 `기타`)
- **창작 연월일**: 소프트웨어 개발이 완료된 날짜 (예: 2024-XX-XX)
- **공표 여부**:
  - 외부에 판매/배포하지 않고 사내/연구용으로 사용 중인 경우: **[미공표]** 선택
  - 온라인에 공개했거나 상용 배포한 경우: **[공표]** 선택 및 최초 공표일 입력
- **사용 언어**: `Python, JavaScript, HTML5, CSS3, Bash`
- **사용 운영체제(OS)**: `Linux (Ubuntu, Debian, RHEL 등)`

### [4단계] 프로그램 개요서 및 설명서 입력
[`docs/program_description.md`](file:///Users/choihayoung/velocityone_tester/docs/program_description.md)의 각 항목 내용을 해당 입력칸에 복사하여 붙여넣거나, 파일로 업로드합니다.
- **개발 목적**: `docs/program_description.md`의 제2항 복사
- **주요 특징 및 독창성**: `docs/program_description.md`의 제3항 복사
- **주요 기능 요약**: `docs/program_description.md`의 제6항 복사
- **작동 환경**: `docs/program_description.md`의 제4항 복사

### [5단계] 복제물(소스코드) 제출
- 복제물 제출 방식에서 **[온라인 파일 제출]** 선택
- 업로드 파일: 프로젝트 루트의 [`copyright_source_submission.txt`](file:///Users/choihayoung/velocityone_tester/copyright_source_submission.txt) (또는 PDF 변환본) 업로드
- *(선택)* 프로젝트 전체 압축 파일(`.zip`)을 함께 업로드 가능

### [6단계] 수수료 결제 및 접수 완료
- 입력 내용 최종 검토 후 전자서명
- 카드/계좌이체로 수수료 납부
- 접수 완료 후 3~5일 이내 심사 진행 (심사관 문의 시 시뮬레이션 모드 및 기능 설명 대응)
- 등록 완료 시 **컴퓨터프로그램저작권 등록증(전자/우편)** 발급

---

## 3. 유용한 명령어 요약

- **소스코드 복제물 다시 추출하기**:
  ```bash
  python3 export_source_for_copyright.py
  ```
- **로컬에서 원클릭으로 실행해보기**:
  ```bash
  ./launch.sh
  ```
- **Linux 단일 바이너리 빌드하기**:
  ```bash
  ./build_linux_binary.sh
  ```
