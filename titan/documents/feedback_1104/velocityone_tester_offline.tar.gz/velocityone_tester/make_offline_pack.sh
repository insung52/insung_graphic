#!/bin/bash
set -e

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

chmod +x *.sh 2>/dev/null || true

echo "=========================================================="
echo "✈ Packaging VelocityOne Tester for USB / Offline Deployment"
echo "=========================================================="

ARCHIVE_NAME="$HOME/velocityone_tester_offline.tar.gz"
cd "$SCRIPT_DIR/.."

export COPYFILE_DISABLE=1
tar --exclude="velocityone_tester/venv" \
    --exclude="velocityone_tester/libs" \
    --exclude="velocityone_tester/__pycache__" \
    --exclude="velocityone_tester/*/__pycache__" \
    --exclude="velocityone_tester/.DS_Store" \
    --exclude="velocityone_tester/*/.DS_Store" \
    --exclude="velocityone_tester/._*" \
    --exclude="velocityone_tester/*/._*" \
    --exclude="velocityone_tester/debs" \
    -czvf "$ARCHIVE_NAME" velocityone_tester/

echo "=========================================================="
echo "✓ USB Offline Package successfully created:"
echo "  $ARCHIVE_NAME"
echo "Copy this file to your USB drive for deployment on Linux server."
echo "=========================================================="
