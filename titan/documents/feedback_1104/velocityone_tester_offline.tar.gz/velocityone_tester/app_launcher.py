#!/usr/bin/env python3
"""
VelocityOne Tester - All-in-One Linux Application Launcher
Launches the FastAPI backend server and automatically opens the desktop UI window.
"""

import sys
import os
import time
import shutil
import signal
import threading
import subprocess
import webbrowser
import urllib.request
import logging

# Ensure local libs and user site-packages are in sys.path
script_dir = os.path.dirname(os.path.abspath(__file__))
libs_dir = os.path.join(script_dir, "libs")
if os.path.isdir(libs_dir) and libs_dir not in sys.path:
    sys.path.insert(0, libs_dir)

py_ver = f"{sys.version_info.major}.{sys.version_info.minor}"
user_site = os.path.expanduser(f"~/.local/lib/python{py_ver}/site-packages")
if os.path.isdir(user_site) and user_site not in sys.path:
    sys.path.insert(0, user_site)

# Ensure DISPLAY is set for Linux GUI environments
if "DISPLAY" not in os.environ:
    os.environ["DISPLAY"] = ":0"

logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] [%(levelname)s] %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger("Launcher")

SERVER_HOST = "0.0.0.0"
SERVER_PORT = 8000
LOCAL_URL = f"http://127.0.0.1:{SERVER_PORT}"

def is_server_ready(url: str, timeout: float = 1.0) -> bool:
    try:
        req = urllib.request.urlopen(f"{url}/api/status", timeout=timeout)
        return req.getcode() == 200
    except Exception:
        return False

def run_backend():
    """Runs FastAPI Uvicorn server in the current process/thread."""
    try:
        import uvicorn
        from main import app
        uvicorn.run(app, host=SERVER_HOST, port=SERVER_PORT, log_level="warning")
    except Exception as e:
        logger.error(f"Backend server encountered an error: {e}")

def find_browser_command() -> tuple[list[str], str]:
    """Finds Chrome, Chromium, Firefox, or system default browser with proper flags."""
    chrome_candidates = [
        "google-chrome",
        "google-chrome-stable",
        "chromium-browser",
        "chromium",
        "brave-browser",
        "microsoft-edge"
    ]
    
    for candidate in chrome_candidates:
        cmd_path = shutil.which(candidate)
        if cmd_path:
            cmd = [
                cmd_path,
                f"--app={LOCAL_URL}",
                "--window-size=1280,840",
                "--no-first-run",
                "--no-default-browser-check"
            ]
            return cmd, candidate

    firefox_path = shutil.which("firefox")
    if firefox_path:
        return [firefox_path, "--new-window", LOCAL_URL], "firefox"

    for generic in ["xdg-open", "x-www-browser", "sensible-browser"]:
        generic_path = shutil.which(generic)
        if generic_path:
            return [generic_path, LOCAL_URL], generic

    return [], "default_browser"

def print_banner():
    banner = f"""
======================================================================
✈   TURTLE BEACH VELOCITYONE TESTER & HARDWARE VISUALIZER
======================================================================
  ● Status:   [ RUNNING ]
  ● Web URL:  {LOCAL_URL}
  ● Network:  http://0.0.0.0:{SERVER_PORT}

  💡 If the browser window did not open automatically, please open 
     your web browser (Chrome / Firefox) and visit:
     👉 {LOCAL_URL}

  ⌨  Press Ctrl + C in this terminal to quit.
======================================================================
"""
    print(banner, flush=True)

def main():
    print("=" * 60)
    print("✈  Turtle Beach VelocityOne Tester - Linux Standalone Launcher")
    print("=" * 60)
    print(f"Target UI URL: {LOCAL_URL}")
    print("Initializing backend server & hardware input subsystem...", flush=True)

    # 1. Start backend server thread
    backend_thread = threading.Thread(target=run_backend, daemon=True)
    backend_thread.start()

    # 2. Wait for backend to be responsive
    max_wait = 10
    start_t = time.time()
    server_ok = False
    while time.time() - start_t < max_wait:
        if is_server_ready(LOCAL_URL, timeout=0.5):
            server_ok = True
            break
        time.sleep(0.3)

    if server_ok:
        logger.info("✓ Backend server is up and listening on port 8000.")
    else:
        logger.warning("Backend starting slowly, proceeding to open UI...")

    print_banner()

    # 3. Launch UI Window / Browser in background
    browser_cmd, browser_name = find_browser_command()
    if browser_cmd:
        logger.info(f"Opening GUI window using '{browser_name}'...")
        try:
            subprocess.Popen(
                browser_cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
        except Exception as e:
            logger.warning(f"Failed to launch {browser_name}: {e}. Falling back to default browser.")
            try:
                webbrowser.open(LOCAL_URL)
            except Exception:
                pass
    else:
        logger.info("Opening system default web browser...")
        try:
            webbrowser.open(LOCAL_URL)
        except Exception as e:
            pass

    # 4. Monitor loop: Keep running until Ctrl+C
    def signal_handler(sig, frame):
        print("\nStopping VelocityOne Tester...", flush=True)
        sys.exit(0)

    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    try:
        while True:
            time.sleep(1)
    except (KeyboardInterrupt, SystemExit):
        signal_handler(None, None)

if __name__ == "__main__":
    main()
