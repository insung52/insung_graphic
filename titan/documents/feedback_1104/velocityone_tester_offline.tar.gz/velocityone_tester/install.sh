#!/bin/bash
# ==============================================================================
# VelocityOne Tester - 100% Offline, Zero-Sudo Installer
# Extracts pre-packaged Python wheels directly without pip or root permissions.
# ==============================================================================

set -e
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

echo "=========================================================="
echo "✈ Installing VelocityOne Tester (Offline, No Sudo Required)"
echo "=========================================================="

mkdir -p "$SCRIPT_DIR/libs"

# 1. Unpack offline Python wheels into local libs and user site-packages
echo "[1/2] Setting up offline Python packages..."
python3 - <<'EOF'
import os
import sys
import glob
import zipfile

script_dir = os.path.dirname(os.path.abspath(__file__)) if '__file__' in globals() else os.getcwd()
wheels_dir = os.path.join(script_dir, "wheels")
libs_dir = os.path.join(script_dir, "libs")
os.makedirs(libs_dir, exist_ok=True)

if not os.path.isdir(wheels_dir):
    print("No wheels directory found, skipping.")
    sys.exit(0)

py_ver = f"{sys.version_info.major}.{sys.version_info.minor}"
user_site = os.path.expanduser(f"~/.local/lib/python{py_ver}/site-packages")
os.makedirs(user_site, exist_ok=True)

all_wheels = glob.glob(os.path.join(wheels_dir, "*.whl"))
py_tag = f"cp{sys.version_info.major}{sys.version_info.minor}"

installed_count = 0
for whl in all_wheels:
    fname = os.path.basename(whl)
    if "none-any" in fname or py_tag in fname:
        try:
            with zipfile.ZipFile(whl, 'r') as zf:
                zf.extractall(libs_dir)
                zf.extractall(user_site)
            installed_count += 1
        except Exception as e:
            print(f"  [!] Failed to extract {fname}: {e}")

print(f"  ✓ Installed {installed_count} offline packages into libs/ and user site-packages")

# Test imports
sys.path.insert(0, libs_dir)
try:
    import fastapi
    import uvicorn
    import websockets
    import starlette
    import pydantic
    print("  ✓ All core dependencies (FastAPI, Uvicorn, WebSockets) verified successfully!")
except ImportError as e:
    print(f"  [!] Dependency check warning: {e}")
EOF

# 2. Setup Desktop Shortcut if Desktop exists
echo "[2/2] Setting up Desktop shortcut..."
DESKTOP_DIR=""
if [ -d "$HOME/Desktop" ]; then
    DESKTOP_DIR="$HOME/Desktop"
elif [ -d "$HOME/바탕화면" ]; then
    DESKTOP_DIR="$HOME/바탕화면"
fi

if [ -n "$DESKTOP_DIR" ]; then
    DESKTOP_FILE="$DESKTOP_DIR/velocityone_tester.desktop"
    cat <<EOF > "$DESKTOP_FILE"
[Desktop Entry]
Version=1.0
Type=Application
Name=VelocityOne Tester
Comment=Turtle Beach VelocityOne Joystick Diagnostics and Real-time Visualizer
Exec=bash -c "cd '$SCRIPT_DIR' && ./launch.sh"
Path=$SCRIPT_DIR
Icon=input-gaming
Terminal=false
Categories=Utility;Development;
StartupNotify=true
EOF
    chmod +x "$DESKTOP_FILE"
    gio set "$DESKTOP_FILE" metadata::trusted true 2>/dev/null || true
    echo "  ✓ Desktop shortcut created: $DESKTOP_FILE"
fi

echo "=========================================================="
echo "✓ Installation Complete! Run './launch.sh' to start."
echo "=========================================================="
