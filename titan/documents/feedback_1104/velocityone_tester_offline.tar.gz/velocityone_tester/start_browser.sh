#!/bin/bash
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

echo "=== Launching VelocityOne Tester (Display Mode) ==="

# Check if server is running, if not start in background
if ! pgrep -f "main.py" > /dev/null; then
    echo "Starting VelocityOne backend server..."
    ./run.sh &
    sleep 3
fi

TARGET_URL="http://localhost:8000"

# Detect browser binary path
BROWSER_BIN=""
if command -v google-chrome > /dev/null; then
    BROWSER_BIN="$(which google-chrome)"
elif command -v chromium-browser > /dev/null; then
    BROWSER_BIN="$(which chromium-browser)"
elif command -v chromium > /dev/null; then
    BROWSER_BIN="$(which chromium)"
fi

if [ -n "$DISPLAY" ]; then
    echo "Desktop environment detected ($DISPLAY). Launching browser window..."
    $BROWSER_BIN --app=$TARGET_URL --window-size=1280,800 &
else
    echo "No active X Desktop found. Launching X11 Display on Monitor (:0)..."
    if command -v xinit > /dev/null; then
        sudo xinit $BROWSER_BIN --app=$TARGET_URL --no-sandbox --user-data-dir=/tmp/chrome_dev --noerrdialogs --disable-infobars --window-size=1280,800 -- :0 -nolisten tcp &
    elif command -v startx > /dev/null; then
        sudo startx $BROWSER_BIN --app=$TARGET_URL --no-sandbox --user-data-dir=/tmp/chrome_dev --noerrdialogs --disable-infobars --window-size=1280,800 -- :0 &
    else
        echo "Please install xinit or start GUI desktop."
    fi
fi
