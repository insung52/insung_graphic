#!/bin/bash
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

echo "=== Launching HDMI Direct Kiosk Mode ==="

# Check if server is running, if not start in background
if ! pgrep -f "main.py" > /dev/null; then
    echo "Starting VelocityOne backend server..."
    ./run.sh &
    sleep 3
fi

# Launch Chromium in kiosk mode via xinit if X is available
if command -v chromium-browser > /dev/null; then
    echo "Launching Chromium Kiosk Mode..."
    xinit chromium-browser --kiosk --noerrdialogs --disable-infobars --check-for-update-interval=31536000 http://localhost:8000 -- :0 -nolisten tcp || \
    chromium-browser --kiosk --noerrdialogs --disable-infobars http://localhost:8000
elif command -v chromium > /dev/null; then
    xinit chromium --kiosk --noerrdialogs --disable-infobars http://localhost:8000 -- :0 -nolisten tcp || \
    chromium --kiosk --noerrdialogs --disable-infobars http://localhost:8000
else
    echo "Chromium is not installed. Please open http://localhost:8000 in your browser."
fi
