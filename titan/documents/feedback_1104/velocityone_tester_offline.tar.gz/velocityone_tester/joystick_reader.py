import asyncio
import time
import math
import logging
import threading
import struct
import os
import glob
import re
import fcntl
from typing import Dict, Any, Optional, List, Tuple

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('joystick_reader')

# Linux Input Event Constants
EV_SYN = 0x00
EV_KEY = 0x01
EV_REL = 0x02
EV_ABS = 0x03

# Linux ioctl for getting ABS limits
# EVIOCGABS(axis) = 0x80184540 + axis (struct input_absinfo is 24 bytes on 64-bit Linux)
EVIOCGABS_BASE = 0x80184540

# Linux ABS Axis Mapping (Code -> Standard Name)
ABS_MAP = {
    0x00: "ABS_X",
    0x01: "ABS_Y",
    0x02: "ABS_Z",
    0x03: "ABS_RX",
    0x04: "ABS_RY",
    0x05: "ABS_RZ",
    0x06: "ABS_THROTTLE",
    0x07: "ABS_RUDDER",
    0x10: "ABS_HAT0X",
    0x11: "ABS_HAT0Y"
}

# Linux Key / Button Mapping (Code -> Display Name B1 ~ B24)
KEY_MAP = {
    0x120: "B1",   # BTN_TRIGGER / BTN_JOYSTICK
    0x121: "B2",   # BTN_THUMB
    0x122: "B3",   # BTN_THUMB2
    0x123: "B4",   # BTN_TOP
    0x124: "B5",   # BTN_TOP2
    0x125: "B6",   # BTN_PINKIE
    0x126: "B7",   # BTN_BASE
    0x127: "B8",   # BTN_BASE2
    0x128: "B9",   # BTN_BASE3
    0x129: "B10",  # BTN_BASE4
    0x12a: "B11",  # BTN_BASE5
    0x12b: "B12",  # BTN_BASE6
    0x12c: "B13",  # BTN_300 / BTN_DEAD
    0x12d: "B14",  # BTN_301
    0x12e: "B15",  # BTN_302
    0x12f: "B16",  # BTN_303
    0x2c0: "B17",  # BTN_TRIGGER_HAPPY1
    0x2c1: "B18",  # BTN_TRIGGER_HAPPY2
    0x2c2: "B19",  # BTN_TRIGGER_HAPPY3
    0x110: "B20",  # BTN_LEFT (Trackpad Click)
    0x2c3: "B20",  # BTN_TRIGGER_HAPPY4
    0x2c4: "B21",  # BTN_TRIGGER_HAPPY5
    0x2c5: "B22",  # BTN_TRIGGER_HAPPY6
    0x2c6: "B23",  # BTN_TRIGGER_HAPPY7
    0x2c7: "B24",  # BTN_TRIGGER_HAPPY8
    
    0x111: "BTN_RIGHT",
    0x112: "BTN_MIDDLE",
    0x113: "BTN_SIDE",
    0x114: "BTN_EXTRA"
}

EVENT_FORMAT = "qqHHi"
EVENT_SIZE = struct.calcsize(EVENT_FORMAT)

class JoystickReader:
    def __init__(self):
        self.device_name: str = "No Hardware (Simulation Active)"
        self.device_path: str = ""
        self.connected: bool = False
        self.simulation_mode: bool = True
        
        self.axes: Dict[str, float] = {}
        self.raw_axes: Dict[str, int] = {}
        self.axis_limits: Dict[str, Dict[str, int]] = {}
        self.buttons: Dict[str, bool] = {}
        self.last_event: Optional[Dict[str, Any]] = None
        self._loop_running = False
        self._threads: List[threading.Thread] = []
        self._active_workers: int = 0
        self._sim_t: float = 0.0

        self._setup_sim_limits()

    def find_velocityone_devices(self) -> List[Tuple[str, str]]:
        """Finds VelocityOne event devices that are accessible for reading."""
        results = []
        try:
            if not os.path.exists("/proc/bus/input/devices"):
                return results

            with open("/proc/bus/input/devices", "r") as f:
                content = f.read()

            blocks = content.strip().split("\n\n")
            for block in blocks:
                lines = block.split("\n")
                name = "Unknown Joystick"
                vendor = ""
                handlers = ""
                
                for line in lines:
                    if line.startswith("I:"):
                        m = re.search(r"Vendor=([0-9a-fA-F]+)", line)
                        if m:
                            vendor = m.group(1).lower()
                    elif line.startswith("N:"):
                        m = re.search(r'Name="([^"]+)"', line)
                        if m:
                            name = m.group(1)
                    elif line.startswith("H:"):
                        m = re.search(r"Handlers=(.*)", line)
                        if m:
                            handlers = m.group(1)

                is_velocityone = (
                    vendor == "10f5" or
                    "turtle beach" in name.lower() or
                    "velocityone" in name.lower() or
                    "flightstick" in name.lower()
                )

                if is_velocityone and handlers:
                    for part in handlers.split():
                        if part.startswith("event"):
                            dev_path = f"/dev/input/{part}"
                            # Only include if file exists AND has read permission
                            if os.path.exists(dev_path) and os.access(dev_path, os.R_OK):
                                results.append((dev_path, name))
        except Exception as e:
            logger.error(f"Error scanning input devices: {e}")

        if not results:
            for path in glob.glob("/dev/input/by-id/*VelocityOne*"):
                real_path = os.path.realpath(path)
                if os.path.exists(real_path) and os.access(real_path, os.R_OK):
                    results.append((real_path, "Turtle Beach VelocityOne Flightstick"))

        return results

    def query_axis_limits_from_fd(self, fd: int):
        """Queries true hardware min/max limits from kernel absinfo ioctl."""
        for code, name in ABS_MAP.items():
            buf = bytearray(24)
            try:
                fcntl.ioctl(fd, EVIOCGABS_BASE + code, buf)
                val, minimum, maximum, fuzz, flat, res = struct.unpack('iiiiii', buf)
                if maximum > minimum:
                    self.axis_limits[name] = {"min": minimum, "max": maximum}
                    logger.info(f"  [Axis Calibrated] {name}: min={minimum}, max={maximum}")
            except Exception:
                pass

    def initialize_devices(self, dev_tuples: List[Tuple[str, str]]) -> bool:
        if not dev_tuples:
            return False
        
        self.device_name = dev_tuples[0][1]
        self.device_path = ", ".join([p[0] for p in dev_tuples])
        self.connected = True
        self.simulation_mode = False
        self.axes.clear()
        self.raw_axes.clear()
        self.buttons.clear()

        default_axes = ["ABS_X", "ABS_Y", "ABS_Z", "ABS_RX", "ABS_RY", "ABS_RZ", "ABS_THROTTLE", "ABS_RUDDER"]
        for a in default_axes:
            self.axis_limits[a] = {"min": 0, "max": 65535}
            if a in ["ABS_RZ", "ABS_THROTTLE", "ABS_RUDDER"]:
                self.raw_axes[a] = 0
                self.axes[a] = 0.0
            else:
                self.raw_axes[a] = 32767
                self.axes[a] = 0.0

        for h in ["ABS_HAT0X", "ABS_HAT0Y"]:
            self.axis_limits[h] = {"min": -1, "max": 1}
            self.raw_axes[h] = 0
            self.axes[h] = 0.0

        for b in range(1, 25):
            self.buttons[f"B{b}"] = False

        logger.info(f"✓ Initialized Physical Driver for {self.device_name} on {self.device_path}")
        return True

    def normalize_axis(self, axis_name: str, raw_val: int) -> float:
        limits = self.axis_limits.get(axis_name, {"min": 0, "max": 65535})
        min_v = limits["min"]
        max_v = limits["max"]

        if axis_name in ["ABS_RZ", "ABS_THROTTLE", "ABS_RUDDER"]:
            if max_v == min_v:
                return 0.0
            norm = (raw_val - min_v) / float(max_v - min_v)
            return round(max(0.0, min(1.0, norm)), 4)
        elif axis_name in ["ABS_HAT0X", "ABS_HAT0Y"]:
            return float(max(-1.0, min(1.0, raw_val)))
        else:
            center = (min_v + max_v) / 2.0
            half_range = (max_v - min_v) / 2.0
            if half_range == 0:
                return 0.0
            norm = (raw_val - center) / half_range
            return round(max(-1.0, min(1.0, norm)), 4)

    async def start_reading(self):
        self._loop_running = True
        asyncio.create_task(self._device_manager_loop())

    async def _device_manager_loop(self):
        scan_ticks = 0
        while self._loop_running:
            # 1. Hardware Disconnected -> Scan periodically + Step simulation
            if not self.connected:
                scan_ticks += 1
                if scan_ticks >= 10: # Scan every ~300ms
                    scan_ticks = 0
                    devs = self.find_velocityone_devices()
                    if devs:
                        logger.info(f"Physical VelocityOne detected! Switching to Live Hardware Mode: {devs}")
                        if self.initialize_devices(devs):
                            self._cleanup_workers()
                            for dev_path, _ in devs:
                                t = threading.Thread(target=self._native_event_worker, args=(dev_path,), daemon=True)
                                t.start()
                                self._threads.append(t)

                if not self.connected:
                    self.simulation_mode = True
                    self.device_name = "No Hardware (Simulation Active)"
                    await self._step_simulation()

            # 2. Hardware Connected -> Monitor active thread health
            else:
                if len(self._threads) > 0 and not any(t.is_alive() for t in self._threads):
                    logger.warning("All physical device threads ended (unplugged). Falling back to Simulation Mode...")
                    self.connected = False
                    self.simulation_mode = True
                    self.device_name = "No Hardware (Simulation Active)"
                    self._cleanup_workers()

            await asyncio.sleep(0.033) # 30 FPS

    def _cleanup_workers(self):
        self._threads.clear()
        self._active_workers = 0

    def _native_event_worker(self, dev_path: str):
        try:
            fd = os.open(dev_path, os.O_RDONLY)
        except Exception as e:
            logger.warning(f"Could not open {dev_path}: {e}")
            return

        self._active_workers += 1
        logger.info(f"Started Native Linux Event Stream on {dev_path}")

        self.query_axis_limits_from_fd(fd)

        try:
            while self._loop_running and self.connected:
                data = os.read(fd, EVENT_SIZE)
                if not data or len(data) < EVENT_SIZE:
                    logger.info(f"Device disconnected on {dev_path}")
                    break
                
                sec, usec, etype, code, val = struct.unpack(EVENT_FORMAT, data)
                
                if etype == EV_ABS:
                    axis_name = ABS_MAP.get(code, f"ABS_{code}")
                    self.raw_axes[axis_name] = val
                    self.axes[axis_name] = self.normalize_axis(axis_name, val)
                    self.last_event = {
                        "type": "EV_ABS",
                        "code": axis_name,
                        "raw": val,
                        "value": self.axes[axis_name],
                        "time": time.time()
                    }
                elif etype == EV_REL:
                    rel_name = "X" if code == 0 else ("Y" if code == 1 else str(code))
                    self.last_event = {
                        "type": "EV_REL",
                        "code": f"Touchpad Swipe ({rel_name})",
                        "raw": val,
                        "value": val,
                        "time": time.time()
                    }
                elif etype == EV_KEY:
                    btn_name = KEY_MAP.get(code, f"BTN_{code}")
                    is_pressed = (val != 0)
                    self.buttons[btn_name] = is_pressed
                    self.last_event = {
                        "type": "EV_KEY",
                        "code": btn_name,
                        "raw": val,
                        "value": is_pressed,
                        "time": time.time()
                    }
        except OSError as e:
            logger.info(f"Device unplugged on {dev_path}: {e}")
        except Exception as e:
            logger.warning(f"Worker stream ended on {dev_path}: {e}")
        finally:
            try:
                os.close(fd)
            except Exception:
                pass
            self._active_workers -= 1
            logger.info(f"Worker closed for {dev_path}. Remaining workers: {self._active_workers}")

    def _setup_sim_limits(self):
        sim_axes = ["ABS_X", "ABS_Y", "ABS_Z", "ABS_RX", "ABS_RY", "ABS_RZ", "ABS_THROTTLE", "ABS_RUDDER", "ABS_HAT0X", "ABS_HAT0Y"]
        for a in sim_axes:
            self.axis_limits[a] = {"min": 0, "max": 65535}
            self.raw_axes[a] = 32767
            self.axes[a] = 0.0
        for b in range(1, 25):
            self.buttons[f"B{b}"] = False

    async def _step_simulation(self):
        self._sim_t += 0.05
        t = self._sim_t
        self.axes["ABS_X"] = round(math.sin(t * 0.8) * 0.8, 3)
        self.axes["ABS_Y"] = round(math.cos(t * 0.6) * 0.7, 3)
        self.axes["ABS_Z"] = round((math.sin(t * 1.0) + 1.0) / 2.0, 3)
        self.axes["ABS_RX"] = round(math.sin(t * 0.5) * 0.9, 3)
        self.axes["ABS_RY"] = round(math.cos(t * 0.7) * 0.6, 3)
        self.axes["ABS_RZ"] = round((math.cos(t * 0.4) + 1.0) / 2.0, 3)
        self.axes["ABS_THROTTLE"] = round((math.sin(t * 0.4) + 1.0) / 2.0, 3)
        self.axes["ABS_RUDDER"] = round((math.cos(t * 0.3) + 1.0) / 2.0, 3)
        
        hat_phase = int(t * 0.5) % 4
        self.axes["ABS_HAT0X"] = 1.0 if hat_phase == 1 else (-1.0 if hat_phase == 2 else 0.0)
        self.axes["ABS_HAT0Y"] = 1.0 if hat_phase == 0 else (-1.0 if hat_phase == 2 else 0.0)

        active_btn_idx = int((t * 2) % 24) + 1
        for b in range(1, 25):
            self.buttons[f"B{b}"] = (b == active_btn_idx)

        self.last_event = {
            "type": "EV_KEY",
            "code": f"B{active_btn_idx} (Simulation)",
            "raw": 1,
            "value": True,
            "time": time.time()
        }

    def get_state(self) -> Dict[str, Any]:
        return {
            "connected": self.connected,
            "device_name": self.device_name,
            "device_path": self.device_path,
            "simulation_mode": self.simulation_mode,
            "axes": self.axes,
            "raw_axes": self.raw_axes,
            "buttons": self.buttons,
            "last_event": self.last_event
        }
